// Callback is an asynchronous equivalent to a function
// callback function are called when the task is completed

var fs = require("fs");

console.log("sync program start");
// synchronous Blocking Code Example
var data = fs.readFileSync('03-callBack.txt');
console.log(data.toString());
console.log("sync program end")




// Asynchronous Non-Blocking Code Example
console.log("Async program start");
fs.readFile('03-callBack.txt', function(err, data) {
	if(err) {
		console.log(err);
	} else {
		console.log(data.toString());
	}
});
console.log("Async program end");
