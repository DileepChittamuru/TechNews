/*
	Node js is a single thread application
	But it supports concurrency via eventloop and call backs
	call backs: The call back function are called when asynchronous function returns the result
	Event loop: Event handling works on observer pattern
			when an event fire , the lister function triggers the respective function to be executed
			These function acts as a observers
*/

// Import events module
var events = require('events');

// Create an eventEmitter object
var eventEmitter = new events.EventEmitter();

function eventHandler() {
	console.log('lister function called')
}
// Bind event and event  handler as follows
eventEmitter.on('eventName', eventHandler);


// fire an event
eventEmitter.emit("eventName");

