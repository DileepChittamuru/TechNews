function animal() {};
animal.prototype.speak = function() {
    console.log("speak calling");
};

function cat(name, age) {
    this.name = name;
    this.age = age;
};

// add animal speak function into cat function
//cat.prototype = Object.create(animal.prototype);

//console.log(cat.prototype.speak());

cat.prototype = new Object(animal.prototype) ;


var pussycat = new cat('pussy', 22);

