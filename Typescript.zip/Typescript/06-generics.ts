	function identity(arg: any): any {
	    return arg;
	}

	identity(10);

	function myIdentity<T>(arg: T): T {
	    return arg;
	}

	let output = myIdentity<string>("Dileep");

	console.log("output", typeof output);

	console.log("number output", myIdentity("Dileep"), typeof myIdentity("Dileep"));

	console.log("string output", myIdentity(21), typeof myIdentity(21));

	/* 
		T might be number so, Number dont have .length method 
	*/
	function loggingIdentity<T>(arg: T): T {
	   // console.log(arg.length);  // Error: T doesn't have .length
	    return arg;
	}

	/* Array */
	function loggingIdentityArray<T>(arg: T[]): T[] {
	    console.log(arg.length);  
	    return arg;
	}

	var arr = [1,2,3];
	loggingIdentityArray(arr);

// Generic Types:
		
	interface GenericIdentityFn<T> {
	    (arg: T): T;
	}

	function identityOurs<T>(arg: T): T {
		console.log("calling", arg)
	    return arg;
	}

	let yoursIdentity: GenericIdentityFn<number> = identityOurs;

	yoursIdentity(30);

// Generic Classes

	class GenericNumber<T> {
		zeroValue: T;
		add: (x:T,y:T) => T;
	}

	let myGenericNumber = new GenericNumber<number>();
	myGenericNumber.zeroValue = 0;
	myGenericNumber.add = function(x, y) { return x+y};

	let stringNumeric = new GenericNumber<string>();
	stringNumeric.zeroValue = "";
	stringNumeric.add = function(x, y) { return x + y; };

	console.log(stringNumeric.add(stringNumeric.zeroValue, "test"));



