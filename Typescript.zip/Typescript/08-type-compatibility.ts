let x = () => ({name: "Alice"});
let y = () => ({name: "Alice", location: "Seattle"});

x = y; // OK
// y = x; // Error, because x() lacks a location property


// typeof
/**
 * Takes a string and adds "padding" to the left.
 * If 'padding' is a string, then 'padding' is appended to the left side.
 * If 'padding' is a number, then that number of spaces is added to the left side.
 */
	function padLeft(value: string, padding: any) {
		console.log("calling");
	    if (typeof padding === "number") {
	    	console.log(Array(padding + 1).join(" ") + value);
	    	return Array(padding + 1).join(" ") + value;
	    }
	    if (typeof padding === "string") {
	        return padding + value;
	    }
	    if (typeof padding === "boolean") {
	        return padding + value;
	    }
	    throw new Error(`Expected string or number, got '${padding}'.`);
	}

	padLeft("Hello world", 4);

	let indentedString = padLeft("Hello world", true);


// insatanceof

// Nullable types
	/*null & undefined are not assignable directly they are always treated differnetly*/
	let s = "foo";
	s = null; // error, 'null' is not assignable to 'string'
	let sn: string | null = "bar";
	sn = null; // ok

	sn = undefined; // error, 'undefined' is not assignable to 'string | null'

// Type Aliases
	/*Type aliases create a new name for a type*/

	type Name = string;
	type NameResolver = () => string;
	type NameOrResolver = Name | NameResolver;
	function getName(n: NameOrResolver): Name {
	    if (typeof n === "string") {
	        return n;
	    }
	    else {
	        return n();
	    }
	}

// Interfaces vs. Type Aliases

// never

// Index types



