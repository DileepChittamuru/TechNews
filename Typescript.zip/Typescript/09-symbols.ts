// symbol is a primitive data type, just like number and string.
// symbol values are created by calling symbol constructor
// symbols are immutable and unique


// export = and import = require() declare

