function identity(arg) {
    return arg;
}
identity(10);
function myIdentity(arg) {
    return arg;
}
var output = myIdentity("Dileep");
console.log("output", typeof output);
console.log("number output", myIdentity("Dileep"), typeof myIdentity("Dileep"));
console.log("string output", myIdentity(21), typeof myIdentity(21));
/*
    T might be number so, Number dont have .length method
*/
function loggingIdentity(arg) {
    // console.log(arg.length);  // Error: T doesn't have .length
    return arg;
}
/* Array */
function loggingIdentityArray(arg) {
    console.log(arg.length);
    return arg;
}
var arr = [1, 2, 3];
loggingIdentityArray(arr);
function identityOurs(arg) {
    console.log("calling", arg);
    return arg;
}
var yoursIdentity = identityOurs;
yoursIdentity(30);
// Generic Classes
var GenericNumber = /** @class */ (function () {
    function GenericNumber() {
    }
    return GenericNumber;
}());
var myGenericNumber = new GenericNumber();
myGenericNumber.zeroValue = 0;
myGenericNumber.add = function (x, y) { return x + y; };
var stringNumeric = new GenericNumber();
stringNumeric.zeroValue = "";
stringNumeric.add = function (x, y) { return x + y; };
console.log(stringNumeric.add(stringNumeric.zeroValue, "test"));
