var x = function () { return ({ name: "Alice" }); };
var y = function () { return ({ name: "Alice", location: "Seattle" }); };
x = y; // OK
// y = x; // Error, because x() lacks a location property
/**
 * Takes a string and adds "padding" to the left.
 * If 'padding' is a string, then 'padding' is appended to the left side.
 * If 'padding' is a number, then that number of spaces is added to the left side.
 */
function padLeft(value, padding) {
    console.log("calling");
    if (typeof padding === "number") {
        console.log(Array(padding + 1).join(" ") + value);
        return Array(padding + 1).join(" ") + value;
    }
    if (typeof padding === "string") {
        return padding + value;
    }
    if (typeof padding === "boolean") {
        return padding + value;
    }
    throw new Error("Expected string or number, got '" + padding + "'.");
}
padLeft("Hello world", 4);
var indentedString = padLeft("Hello world", true);
