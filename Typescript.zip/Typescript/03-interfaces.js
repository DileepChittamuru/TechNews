/* Basic interface */
function printLabel(labelledObj) {
    console.log(labelledObj.label);
}
var myObj = { size: 10, label: "Size 10 Object" };
printLabel(myObj);
/*
    @name: createSquare
    @param {Object}: SquareConfig contains color & width
    @returns {Object}: newSquare conatins color & area
*/
function createSquare(config) {
    var newSquare = { color: "white", area: 100 };
    if (config.color) {
        newSquare.color = config.color;
    }
    if (config.width) {
        newSquare.area = config.width * config.width;
    }
    console.log("newSquare", newSquare);
    return newSquare;
}
;
var myConfig = createSquare({ color: "green" });
var p1 = { x: 10, y: 20 };
var searchFun = function (src, substring) {
    var result = src.search(substring);
    console.log("result", result);
    return result > -1;
};
searchFun('cdr', 'c');
