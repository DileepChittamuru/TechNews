/* Basic interface */

	interface LabelledValue {
	    label: string;
	}

	function printLabel(labelledObj: LabelledValue) {
	    console.log(labelledObj.label);
	}

	let myObj = {size: 10, label: "Size 10 Object"};
	
	printLabel(myObj);

// Optional Properties

	/*
	*	optional properties using question mark before colon
	*/

	interface SquareConfig {
	    color?: string;
    	width?: number;
	}
	/*
		@name: createSquare
		@param {Object}: SquareConfig contains color & width
		@returns {Object}: newSquare conatins color & area
	*/
	function createSquare(config: SquareConfig): {color: string; area: number} {
		let newSquare = {color: "white", area: 100};

		if(config.color) {
			newSquare.color = config.color;
		}

		if(config.width) {
			newSquare.area = config.width * config.width;
		}

		console.log("newSquare", newSquare);
		return newSquare;
	};

	let myConfig = createSquare({color: "green"});

// Readonly proeprties

	/*
		Some properties should only be modifiable when an object is first created.
		You can specify this by putting readonly before the name of the property
	*/

	interface Point {
    	readonly x: number;
    	readonly y: number;
	}

	let p1: Point = { x: 10, y: 20 };

	// p1.x = 5; // error!

	/*
	* readonly vs const
	* 
	* const used for variables
	* readonly used for object proeprties
	*/
	
// Function Types

	interface searchFun {
		(src: string, substring: string): boolean;
	}

	let searchFun =  function(src : string, substring: string) {
		let result = src.search(substring);
		console.log("result", result);
		return result > -1;
	}

	searchFun('cdr', 'c');

// Indexable Types

	interface stringArray {
		[index: number] : string
	}

	let myArray = stringArray;

	myArray = ["dilep", "reddy"];

 // Class Types

 	