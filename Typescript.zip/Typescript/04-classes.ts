/*
	Example 1
*/
	class Greeter {
	    greeting: string;
	    constructor(message: string) {
	        this.greeting = message;
	    }
	    greet() {
	        return "Hello, " + this.greeting;
	    }
	}

	let greeter = new Greeter("world");

/*
example 2
*/

	class Animal {
	    move(distanceInMeters: number = 0) {
	        console.log(`Animal moved ${distanceInMeters}m.`);
	    }
	}

	class Dog extends Animal {
	    bark() {
	        console.log('Woof! Woof!');
	    }
	}

	const dog = new Dog();
	dog.bark(); // 'Woof! Woof!'
	dog.move(10); // Animal moved 10m.
	dog.bark(); // 'Woof! Woof!'

/*
* example 3 inheritence
*/

	class myAnimal {
	    name: string;
	    constructor(theName: string) { 
	    	this.name = theName;
	    }
	    move(distanceInMeters: number = 0) {
	        console.log(`${this.name} moved ${distanceInMeters}m.`);
	    }
	}

	class Snake extends myAnimal {
	    constructor(name: string) { 
	    	console.log("before super Snake");
	    	super(name);
	    	console.log("after super Snake");
	    }
	    move(distanceInMeters = 5) {
	        console.log("Slithering...");
	        super.move(distanceInMeters);
	    }
	}

	class Horse extends myAnimal {
	    constructor(name: string) { super(name); }
	    move(distanceInMeters = 45) {
	        console.log("Galloping...");
	        super.move(distanceInMeters);
	    }
	}

	let sam = new Snake("Sammy the Python");
	let tom: Animal = new Horse("Tommy the Palomino");

	sam.move(); 
	tom.move(34);

	// out-put
	/*
		Slithering
		Sammy the Python moved 5m.
		Galloping..
		Tommy the Palomino moved 34m.
	*/

// modifiers
	// In TypeScript, each member is public by default.
	// When a member is marked private, it cannot be accessed from outside of its containing class
	// The protected modifier acts much like the private modifier with the exception that members declared protected can also be accessed within deriving classes
// Readonly modifier
	class Octopus {
	    readonly name: string;
	    readonly numberOfLegs: number = 8;
	    constructor (theName: string) {
	        this.name = theName;
	    }
	}
	let dad = new Octopus("Man with the 8 strong legs");

// Accessors
	// TypeScript supports getters/setters as a way of intercepting accesses to a member of an object.

	// Let’s convert a simple class to use get and set.

	let passcode = "secret passcode";

	class Employee {
	    private _fullName: string;

	    get fullName(): string {
	        return this._fullName;
	    }

	    set fullName(newName: string) {
	        if (passcode && passcode == "secret passcode") {
	            this._fullName = newName;
	        }
	        else {
	            console.log("Error: Unauthorized update of employee!");
	        }
	    }
	}

	let employee = new Employee();
	employee.fullName = "Bob Smith";
	if (employee.fullName) {
	    console.log(employee.fullName);
	}

// static properties

	// static members are load at first

// Abstract Classes

	// abstract classes are always base class 
	// it contain few impplemtation methods and method declarations




	