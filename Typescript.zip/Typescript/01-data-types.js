// Boolean
var isDone = true;
console.log("boolean=>before", isDone);
isDone = false;
console.log("boolean=>After", isDone);
// Number
var hex = 20;
console.log("number==>Before", hex);
hex = 30;
console.log("number==>After", hex);
// String
var color = "green";
console.log("string==>Before", color);
color = "red";
console.log("string==>after", color);
// Array
var arr = [1, 2, 3, 4];
console.log("array==>", arr, arr[9]);
// Tuple
var tple = [23, 'cdr'];
console.log(tple[1]);
// Enum
var Color;
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 1] = "Green";
    Color[Color["Blue"] = 2] = "Blue";
})(Color || (Color = {}));
var c = Color.Red;
console.log("enum==>", c);
var colorName = Color[2];
console.log("enum==>", colorName);
// Any
var notSure = false;
console.log("boolean any", notSure);
notSure = "cdr";
console.log("string any", notSure);
notSure = 1;
console.log("number any", notSure);
var arryAny = [1, "true", false];
console.log("arrAny", arryAny);
// Type assertion
var str = "cdr is a goo dboyd";
var strLength = str.length;
console.log("strLength", strLength);
