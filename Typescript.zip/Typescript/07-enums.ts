
// Numberic enums

// Default
enum Direction {
    Up,
    Down,
    Left,
    Right,
}

console.log(Direction.Up); // 0
console.log(Direction.Down); // 1
console.log(Direction.Left); // 2
console.log(Direction.Right); // 3

// Colors
enum Colors {
    Blue = 1,
    Green,
    Red,
    Pink,
}

console.log(Direction.Up); // 1
console.log(Direction.Down); // 2
console.log(Direction.Left); // 3
console.log(Direction.Right); // 4

// String enums

	enum DirectionString {
	    Up = "UP",
	    Down = "DOWN",
	    Left = "LEFT",
	    Right = "RIGHT",
	}

// Heterogeneous enums

	enum BooleanLikeHeterogeneousEnum {
    	No = 0,
    	Yes = "YES",
	}

//  enum constants

		enum E { X }

	console.log("X",E.X) // 0

//
	enum FileAccess {
	    // constant members
	    None,
	    Read    = 1 << 1,
	    Write   = 1 << 2,
	    ReadWrite  = Read | Write,
	    // computed member
	    G = "123".length
	}
	console.log("FileAccess", FileAccess.Read)