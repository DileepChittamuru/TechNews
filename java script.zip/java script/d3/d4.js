const url = 'https://raw.githubusercontent.com/FreeCodeCamp/ProjectReferenceData/master/cyclist-data.json',
  margin = {top: 40,right: 20,bottom: 60,left: 60},
  width = 800,
  height = 600;

const tooltip = d3.select('body').append('div')
  .attr('id', 'tooltip');

const x = d3.scaleTime()
  .range([0, width]);

const y = d3.scaleLinear()
  .range([height, 0]);

const chart = d3.select('#chart')
  .attr('width', width + margin.left + margin.right)
  .attr('height', height + margin.top + margin.bottom)
  .append('g')
  .attr('transform', `translate(${margin.left}, ${margin.top})`);

chart.append('text')             
  .attr('transform', `translate(${width/2},${margin.top - 54})`)
  .attr('id', 'title')
  .text('Doping in Professional Cycling: Le Tour de France at Alpe d\'Huez');

d3.request(url)
  .mimeType('application/json')
  .response((xhr) => JSON.parse(xhr.responseText))
  .get((data) => {
    
    const date = (seconds) => new Date(0, 0, 0, 0, 0, seconds);
  
    x.domain([date(data[data.length - 1].Seconds - data[0].Seconds), date(0)]);
    y.domain([d3.max(data, (d) => d.Place), 1]);
  
    chart.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x).ticks(7).tickFormat(d3.timeFormat('%M:%S')));
    
    chart.append('text')             
      .attr('transform', `translate(${width/2},${height + margin.top})`)
      .attr('id', 'x-label')
      .text('Minutes Behind Fastest Time');

    chart.append('g')
      .call(d3.axisLeft(y).tickValues([1].concat(y.ticks())));
  
    chart.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('dx', '-20em')
      .attr('dy', '-2.5em')
      .text('Ranking');
  
    chart.append('circle')
      .attr('cx', '600')
      .attr('cy', '400')
      .attr('r', '5')
      .style('fill', '#C13522');
  
    chart.append('text')
      .attr('x', '610')
      .attr('y', '405')
      .text('Allegations of Doping');
  
    chart.append('circle')
      .attr('cx', '600')
      .attr('cy', '430')
      .attr('r', '5')
      .style('fill', '#225FC1');
  
    chart.append('text')
      .attr('x', '610')
      .attr('y', '435')
      .text('No Doping Allegations');
  
    chart.selectAll('.circle')
      .data(data)
      .enter().append('circle')
      .attr('class','circle')
      .attr('cx', (d) => x(date(d.Seconds - data[0].Seconds)))
      .attr('cy', (d) => y(d.Place))
      .attr('r', 5)
      .style('fill', (d) => d.Doping.length > 2 ? '#C13522' : '#225FC1')
      .on('mouseover', (d) => {
        tooltip.transition()
          .duration(100)		
          .style('opacity', .9);
        tooltip.text(`Ranking: ${d.Place} - ${d.Name} - Year ${d.Year} - Time: ${d.Time}`)
          .style('left', `${d3.event.pageX + 2}px`)	
          .style('top', `${d3.event.pageY - 18}px`);
      })
      .on('mouseout', () => {		
        tooltip.transition()		
        .duration(400)		
        .style('opacity', 0);	
      });
})