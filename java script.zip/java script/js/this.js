'use strict'
var person1 = {
  name: 'Chris',
  greeting: function() {
    console.log('Hi! I\'m ' + this.name + '.');
  }
}

var person2 = {
  name: 'Brian',
  greeting: function() {
    console.log('Hi! I\'m ' + this.name + '.');
  }
}

person1.greeting();
person2.greeting();