

var floors = { 0: true, 1: false, 2: false, 3: false , 4: false};

var elevator = function(currentFloor) {
	this.name = currentFloor;
}

var getElevator = function(source, destination) {
	
}

getElevator(0, 4);


 