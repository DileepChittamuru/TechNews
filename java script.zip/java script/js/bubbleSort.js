



var unsortedArray = [4, 2, 3, 1, 5 , 6];
var sortedArray = unsortedArray;

function sortArray()  {
   console.log('unsortedArray', unsortedArray)
    console.log('unsortedArray', unsortedArray)
    let swapped = false;
    for(var i = 1; i < unsortedArray.length; i++){
        var curr = unsortedArray[i]; // 2
        var prev = unsortedArray[i-1]; // 4

        if(prev > curr){
            swapped = true;
            sortedArray[i-1] = curr ; //prev
            sortedArray[i] =  prev; // cur
            console.log("sort case",i, sortedArray);
        }
    }
    if(swapped) {
        return sortArray();
    }
}

sortArray();

console.log(sortedArray)