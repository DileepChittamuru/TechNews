'use strict';

var abc = {}

//==================================

var def = {
  name: 'adc',
  age: 21
}

//===============================================
// using new operartor iheriting from constructor function
function dog(){
  this.eat = function() {
    console.log('calling eat');
  }
}

var snoopy = new dog();
console.log("snoopy", snoopy)

var bittu = new(dog);
console.log("bittu", bittu)

function person(name, age) {
  this.name = name;
  this.age = age;
}
var dileep = new person('dr', 21);

// using new operator inheriting from super Object() 

var person1 = new Object();

var person1 = new Object({
  name: 'Chris',
  age: 38,
  greeting: function() {
    alert('Hi! I\'m ' + this.name + '.');
  }
});
//===============================================
// using create method

var person2 = Object.create(person1);

var person4 = Object.create(person2);

console.log('person4', person4['__proto__']['__proto__'].age);

//================================================


