 function check() {
        var str = 'madam';
        var temp;
        for (var i=str.length-1;i<=0;i--) {
                temp = temp+str[i]
        }
     }


      function investment() {
        // 0 1  2  3  5  8
        //   f1 f2 f
        //      f1 f2 f
        var f1 = 1;
        var f2 = 2;
        var f = f1 + f2;
        while(f < 15) {
            f1 = f2
            f2 = f;
            f = f1 + f2;
            console.log(f);
        }
    }


    function swap() {
        var a = 5;
        var b = 10;
       console.log("before ",a ,b);
        a = a + b; 
        b = a-b;
        a = a-b;
        console.log("after ",a ,b);
    }

    function merge(){
    	var ar1 = [2,4,6,8,10, 11];
		var ar2 = [1,4,5,3,7,9];
		var ar3 = ar1.concat(ar2.filter(function(item){ return ar1.indexOf(item) < 0}));
		ar3.sort(function(a,b){return a-b});
    }


    function minMax(){
    	var arr = [2, 3, 10,99, 50, 8,1];
		var min = arr[0];
		var max = arr[0];
		for (var i=1; i<arr.length; i++) {
    		min = (min > arr[i]) ? arr[i] : min;
    		max = (max > arr[i]) ? max : arr[i];
		}
		console.log(min, max)
    }
    
    


