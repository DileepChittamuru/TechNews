function Brick() {
    this.width = 10;
    this.height = 20;
}
function BlueGlass() {
    Brick.call(this);
    this.color = 'blue';
    this.opacity = 0.5;
}

var bg = new BlueGlass();


console.log("bg.width", bg.width);
console.log("height", bg.height);
console.log('solor', bg.color);
