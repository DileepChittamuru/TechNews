"use strict";

	var express = require('express');

	var app = express();

  var cors = require('cors')

  var app = express()
  app.use(cors());

	app.use('/',express.static(__dirname + '/'));

  var port = process.env.PORT || 3000;
	app.listen(port, function() {
    console.log("server");
  });

  var http = require('http');

   /**
   *
   * HTTP server
   */
  var server = http.createServer(function(request, response) {
      // Not important for us. We're writing WebSocket server,
      // not HTTP server
  });

  

  